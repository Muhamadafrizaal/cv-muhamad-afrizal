# Network Monitoring & Incident Log

## Tujuan
Membuat simulasi pencatatan dan penanganan incident untuk lingkungan Network Operation Center (NOC).

## Skenario
Monitoring menemukan perangkat `RTR-JKT-01` tidak merespons ping.

## Alur Penanganan
1. Deteksi alert.
2. Verifikasi ping dan gateway.
3. Cek interface/link.
4. Cek kemungkinan packet loss.
5. Eskalasi jika perangkat/site tidak dapat dipulihkan.
6. Catat tindakan dan hasil pada incident log.

## Contoh Incident Log

| ID | Device | Severity | Symptom | Action | Status |
|---|---|---|---|---|---|
| INC-001 | RTR-JKT-01 | High | Request timeout | Ping, cek gateway, eskalasi vendor | Resolved |
| INC-002 | SW-JKT-02 | Medium | Packet loss | Cek kabel/interface | Monitoring |

## Tools
- Ping
- Tracert/Traceroute
- IPConfig/Ifconfig
- Basic MikroTik/Cisco concepts
- Spreadsheet / ticketing

> Data pada project ini adalah data simulasi, bukan data perusahaan.
