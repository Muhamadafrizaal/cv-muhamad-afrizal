# IT Helpdesk Ticketing Simulation

## Tujuan
Mensimulasikan proses IT Support dari laporan user sampai penyelesaian tiket.

## Workflow
`User Report → Ticket → Categorization → Diagnosis → Resolution → Verification → Closure`

## Contoh Ticket

| Ticket | Category | Priority | Problem | Resolution |
|---|---|---|---|---|
| HD-001 | Network | High | Internet tidak terhubung | Cek IP, gateway, DNS |
| HD-002 | Hardware | Medium | PC tidak menyala | Cek power, kabel, PSU |
| HD-003 | Software | Low | Aplikasi error | Restart, update, reinstall |

## KPI sederhana
- Response time
- Resolution time
- First contact resolution
- Reopen rate
- Ticket backlog

Semua data adalah simulasi untuk kebutuhan portfolio.
